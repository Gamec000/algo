#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./genetic --disable-gpu --algorithm randomx --pool rx.unmineable.com:3333 --wallet TNW48n9Wz42Bv4At5EmDhZuvJg4S3AH9GQ
